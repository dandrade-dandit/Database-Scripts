-- D:\Avelar\Projetos_Infraero\Forms\Preg�o\scpp.sql
--
-- Generated for Oracle 8.1 on Mon Aug 28  13:29:03 2006 by Server Generator 6.5.52.1.0


SPOOL scpp.lst

@@scpp.tab
@@scpp.ind
@@scpp.con

SPOOL OFF
