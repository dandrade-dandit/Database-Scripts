/* Microsoft SQL Server - Scripting			*/
/* Server: 10.5.17.31					*/
/* Database: AIMS					*/
/* Creation Date 4/10/01 6:30:59 PM 			*/

/****** Object:  Stored Procedure dbo.sp_Chegadas    Script Date: 4/10/01 6:31:03 PM ******/
/****** Object:  Stored Procedure dbo.sp_Chegadas    Script Date: 3/15/01 3:54:23 PM ******/
/*
 Todos os voos validos que estao chegando ao aeroporto
*/
CREATE PROCEDURE sp_Chegadas AS

SELECT
	CONVERT(CHAR(5),CHG.DH_CHG_EST,3) + ' ' + CONVERT(CHAR(5),CHG.DH_CHG_EST,8) as data,
	CONVERT(VARCHAR(17),CHG.DH_CHG_EST,13) AS datax, CHG.NR_CHG_HOT AS voo, CHG.CD_CHG AS codchg,  
	COM.NM_COM AS cia, SIT.NM_SIT_LOC AS observacao, CID.NM_CID AS escala, chg.NR_CHG_VOO as numvoo, com.SG_COM_IAT_003 as sigla,
	CHG.CD_SIT as codsit
FROM 
	T_CHG CHG, T_COM COM, T_SIT SIT, T_ECC001 ECC, T_AER AER, T_CID CID
WHERE
	CHG.FL_CHG_TEL = 1 AND CHG.CD_SIT <> 10 AND
	CHG.CD_COM = COM.CD_COM AND CHG.CD_SIT = SIT.CD_SIT AND
	CHG.CD_CHG = ECC.CD_CHG AND ECC.CD_AER  = AER.CD_AER AND
	AER.CD_CID = CID.CD_CID ORDER BY CHG.DH_CHG_EST
GO

/****** Object:  Stored Procedure dbo.sp_ChegadasCompleto    Script Date: 4/10/01 6:31:03 PM ******/
/****** Object:  Stored Procedure dbo.sp_ChegadasCompleto    Script Date: 22/03/2001 11:35:55 ******/
CREATE PROCEDURE sp_ChegadasCompleto AS
/*
 Todos os voos validos que estao chegando (ou chegaram) ao aeroporto
*/
SELECT
	CONVERT(CHAR(17),CHG.DH_CHG_EST,13) AS datax,
	CONVERT(CHAR(5),CHG.DH_CHG_EST,3) + ' ' + CONVERT(CHAR(5),CHG.DH_CHG_EST,8) as data, 
	CHG.NR_CHG_HOT AS voo, CHG.CD_CHG AS codchg,  
	COM.NM_COM AS cia, SIT.NM_SIT_LOC AS observacao, CID.NM_CID AS escala, chg.NR_CHG_VOO as numvoo, com.SG_COM_IAT_003 as sigla
FROM 
	T_CHG CHG, T_COM COM, T_SIT SIT, T_ECC001 ECC, T_AER AER, T_CID CID
WHERE
	CHG.FL_CHG_TEL = 1 AND
	CHG.CD_SIT = 10 AND
	DATEDIFF(dd,DT_CHG,getdate()) <= 1 AND
	CHG.CD_COM = COM.CD_COM AND CHG.CD_SIT = SIT.CD_SIT AND
	CHG.CD_CHG = ECC.CD_CHG AND ECC.CD_AER  = AER.CD_AER AND
	AER.CD_CID = CID.CD_CID ORDER BY CHG.DH_CHG_EST
GO

/****** Object:  Stored Procedure dbo.sp_Now    Script Date: 4/10/01 6:31:03 PM ******/
/* retorna a data e hora do servidor local */
CREATE PROCEDURE sp_Now AS
select Now = convert(char(10),getdate(),103) + ' ' + convert(char(5),getdate(),8)
GO

/****** Object:  Stored Procedure dbo.sp_Partidas    Script Date: 4/10/01 6:31:03 PM ******/
/****** Object:  Stored Procedure dbo.sp_Partidas    Script Date: 3/15/01 3:54:23 PM ******/
/*
 Todos os voos validos que estao partindo do aeroporto 
*/
CREATE PROCEDURE sp_Partidas AS

SELECT
	CONVERT(CHAR(17),PAR.DH_PAR_EST,13) AS datax,
	CONVERT(CHAR(5),PAR.DH_PAR_EST,3) + ' ' + CONVERT(CHAR(5),PAR.DH_PAR_EST,8) as data,
	PAR.NR_PAR_HOT AS voo, PAR.CD_PAR AS codpar,PAR.CD_SIT as codsit,
	COM.NM_COM AS cia, SIT.NM_SIT_LOC AS observacao, CID.NM_CID AS escala, par.NR_PAR_VOO as numvoo, com.SG_COM_IAT_003 as sigla
FROM
	T_PAR PAR, T_COM COM, T_SIT SIT, T_ECP001 ECP, T_AER AER, T_CID CID
WHERE
	PAR.FL_PAR_TEL = 1 AND PAR.CD_SIT <> 10 AND
	PAR.CD_COM = COM.CD_COM AND PAR.CD_SIT = SIT.CD_SIT AND
	PAR.CD_PAR = ECP.CD_PAR AND ECP.CD_AER  = AER.CD_AER AND
	AER.CD_CID = CID.CD_CID ORDER BY PAR.DH_PAR_EST
GO

/****** Object:  Stored Procedure dbo.sp_PartidasCompleto    Script Date: 4/10/01 6:31:03 PM ******/
/****** Object:  Stored Procedure dbo.sp_PartidasCompleto    Script Date: 22/03/2001 11:35:55 ******/
CREATE PROCEDURE sp_PartidasCompleto AS
/*
 Todos os voos que estao partindo do aeroporto. Situacao de todo o dia. 
*/
SELECT
	CONVERT(CHAR(17),PAR.DH_PAR_EST,13) AS datax,
	CONVERT(CHAR(5),PAR.DH_PAR_EST,3) + ' ' + CONVERT(CHAR(5),PAR.DH_PAR_EST,8) as data,
	PAR.NR_PAR_HOT AS voo, PAR.CD_PAR AS codpar,
	COM.NM_COM AS cia, SIT.NM_SIT_LOC AS observacao, CID.NM_CID AS escala, par.NR_PAR_VOO as numvoo, com.SG_COM_IAT_003 as sigla
FROM
	T_PAR PAR, T_COM COM, T_SIT SIT, T_ECP001 ECP, T_AER AER, T_CID CID
WHERE
	PAR.FL_PAR_TEL = 1 AND 
	PAR.CD_SIT = 10 AND
	DATEDIFF(dd,PAR.DH_PAR_EST,getdate()) <= 1 AND
	PAR.CD_COM = COM.CD_COM AND PAR.CD_SIT = SIT.CD_SIT AND
	PAR.CD_PAR = ECP.CD_PAR AND ECP.CD_AER  = AER.CD_AER AND
	AER.CD_CID = CID.CD_CID ORDER BY PAR.DH_PAR_EST
GO

/****** Object:  Stored Procedure dbo.sp_PesquisaVR    Script Date: 4/10/01 6:31:03 PM ******/
/****** Object:  Stored Procedure dbo.sp_PesquisaVR    Script Date: 3/15/01 3:54:23 PM ******/
CREATE PROCEDURE sp_PesquisaVR (@hfr varchar(7)='', @orientacao varchar(7)='', @sgaer varchar(4)='', @voo varchar(7)='', @cia varchar(3)='', @periodo varchar(4)='') AS
declare @condicao varchar(255)
declare @condicao2 varchar(255)
declare @condicao3 varchar(255)
declare @pos int

declare @CondPeriodo1 varchar(255)
declare @CondPeriodo2 varchar(255)
declare @origem int
declare @destino int
declare @aux varchar (100)
declare @CampoHora varchar (15)
declare @Faixa char(1)

select @CondPeriodo1 = ""
select @CondPeriodo2 = ""

select @condicao = ""
/* frenquencia */
if @hfr <> "" begin 
   select @pos = 1
   while @pos <= datalength(@hfr) begin   
      if @condicao = "" begin
         select @condicao = "(t_hfr.ds_hfr like '%" + substring(@hfr,@pos,1) + "%')"
      end
      else begin
         select @condicao = @condicao + " and (t_hfr.ds_hfr like '%" + substring(@hfr,@pos,1) + "%')"
      end 
      select @pos = @pos + 1
      continue
   end 
end
/* aeroporto, testando se eh origem ou destino */
if @condicao = "" begin
   if @orientacao = "origem" begin
      select @condicao = "(t_het.sg_aer_ori = '" + @sgaer + "')"
   end
   else begin
      if @orientacao = "destino" begin
         select @condicao = "(t_het.sg_aer_des = '" + @sgaer + "')"
      end
   end
end
else begin
   if @orientacao = "origem" begin
      select @condicao = @condicao + " and (t_het.sg_aer_ori = '" + @sgaer + "')"
   end
   else begin
      if @orientacao = "destino" begin
         select @condicao = @condicao + " and (t_het.sg_aer_des = '" + @sgaer + "')"
      end
   end
end
/* voo */
if @voo <> "" begin
   if @condicao = "" begin
      select @condicao = "(t_het.cd_hot = '" + @voo + "')"
   end
   else begin
      select @condicao = @condicao + " and (t_het.cd_hot = '" + @voo + "')"
   end end
/* cia aerea */
if @cia <> "" begin
   if @condicao = "" begin
      select @condicao = "(T_HOT001.SG_COM = '" + @cia + "')"
   end
   else begin
      select @condicao = @condicao + " and (T_HOT001.SG_COM = '" + @cia + "')"
   end end
if @condicao <> "" begin
   select @condicao = @condicao + " AND "
end
if @orientacao = "origem" begin
   select @condicao2 = " WHERE (t_het.sg_aer_des = 'SBRF')"
end
else begin
   if @orientacao = "destino" begin
      select @condicao2 = " WHERE (t_het.sg_aer_ori = 'SBRF')"
   end
end
if @orientacao = "origem" begin
   select @condicao3 = " <= "
end
else begin
   if @orientacao = "destino" begin
      select @condicao3 = " >= "
   end
   else begin
      select @condicao3 = " = "
   end
end

/******* Periodo **********/
/* Faixas
1 -> 00:00AM ate 06:00AM
2 -> 06:00AM ate 12:00PM
3 -> 12:00PM ate 06:00PM
4 -> 06:00PM ate 11:59PM
*/
if @periodo <> "" begin
   if @orientacao = "origem" begin
      select @origem = 1
      select @destino = 0
   end else if @orientacao = "destino" begin
      select @origem = 0
      select @destino = 1
   end else begin
      select @origem = 1
      select @destino = 1
   end
   /* Origem */
   if @origem = 1 begin
      select @pos = 1
      while @pos <= datalength(@Periodo) begin
         /* escolhe a faixa */ 
         select @Faixa = substring(@Periodo,@pos,1)
         select @aux = 
                case @Faixa
                     when "1" then "(hr_het_chg BETWEEN '00:00' AND '06:00')"
                     when "2" then "(hr_het_chg BETWEEN '06:00' AND '12:00')"
                     when "3" then "(hr_het_chg BETWEEN '12:00' AND '18:00')"
                     when "4" then "(hr_het_chg BETWEEN '18:00' AND '23:59')"
                     else ""
                end
         if @CondPeriodo1 = "" begin
            select @CondPeriodo1 = @aux 
         end else begin
            select @CondPeriodo1 = @CondPeriodo1 + " OR " + @aux 
         end
         /* proxima faixa */ 
         select @pos = @pos + 1
         continue
      end
   end
   /* Destino */
   if @destino = 1 begin
      select @pos = 1
      while @pos <= datalength(@Periodo) begin
         /* escolhe a faixa */ 
         select @Faixa = substring(@Periodo,@pos,1)
         select @aux = 
                case @Faixa
                     when "1" then "(hr_het_par BETWEEN '00:00' AND '06:00')"
                     when "2" then "(hr_het_par BETWEEN '06:00' AND '12:00')"
                     when "3" then "(hr_het_par BETWEEN '12:00' AND '18:00')"
                     when "4" then "(hr_het_par BETWEEN '18:00' AND '23:59')"
                     else ""
                end
         if @CondPeriodo2 = "" begin
            select @CondPeriodo2 = @aux 
         end else begin
            select @CondPeriodo2 = @CondPeriodo2 + " OR " + @aux 
         end
         /* proxima faixa */ 
         select @pos = @pos + 1
         continue
      end
   end
   if @CondPeriodo2 <> "" and @CondPeriodo1 <> "" begin
      select @CondPeriodo2 = " OR " + @CondPeriodo2 
   end
   if @condicao2 = "" begin
      select @CondPeriodo1 = "WHERE (" + @CondPeriodo1
      select @CondPeriodo2 = @CondPeriodo2 + ")"
   end else begin
      select @CondPeriodo1 = "AND (" + @CondPeriodo1
      select @CondPeriodo2 = @CondPeriodo2 + ")"
   end

end
/******* Fim Periodo ********************/

/* Pesquisa de Voos Regulares */
/* -------------------------- */
/* Recebe os campos de pesquisa e retorna um conjuntos de voos */
/* que respondem aos criterios passados */
exec ('SELECT DISTINCT VRFinal.Voo, VRFinal.CD_HVE, VRFinal.CD_HFR, T_HET.CD_HET, T_HOT001.SG_COM AS Cia, T_HOT001.TP_HOT AS Classe, T_HOT001.TP_HOT_NAT AS Natureza, T_HET.TP_HET_CTG AS Categoria, T_HFR.DS_HFR AS Frequencia, T_HET.SG_AER_ORI AS AER_Origem, convert(char(5),T_HET.HR_HET_PAR,8) AS HoraOrigem, CID_Origem.NM_CID AS Origem, T_HET.SG_AER_DES AS AER_Destino, convert(char(5),T_HET.HR_HET_CHG,8) AS HoraDestino, CID_Destino.NM_CID AS Destino

FROM
(
/* VRPesquisa */
/* este primeiro select � utilizado para fazer a filtragem dos parametros de pesquisa */
SELECT DISTINCT VRPesquisa.Voo, VRPesquisa.CD_HVE, VRPesquisa.CD_HFR
FROM 
(
SELECT T_HET.CD_HOT AS Voo, T_HET.CD_HVE, T_HET.CD_HFR, T_HET.CD_HET FROM T_HET INNER JOIN (T_HFR INNER JOIN (T_HVE INNER JOIN T_HOT001 ON T_HVE.CD_HOT = T_HOT001.CD_HOT) ON (T_HFR.CD_HOT = T_HVE.CD_HOT) AND (T_HFR.CD_HVE = T_HVE.CD_HVE)) ON (T_HET.CD_HOT = T_HFR.CD_HOT) AND (T_HET.CD_HVE = T_HFR.CD_HVE) AND (T_HET.CD_HFR = T_HFR.CD_HFR)
WHERE ' + @condicao + '
/* Condicoes fixas - NAO ALTERAR */
  (T_HVE.DT_HVE_INI<=getdate())
 AND (T_HVE.DT_HVE_FIM Is Null Or T_HVE.DT_HVE_FIM>getdate())
 AND (T_HOT001.FL_HOT_TEL=1)
)  AS VRPesquisa 
 INNER JOIN 
(
/* VRPesquisa2 */
/* este segundo select estabelesce o aeroporto de referencia, neste caso Recife (SBRF) */
SELECT T_HET.CD_HOT AS Voo, T_HET.CD_HVE, T_HET.CD_HFR, T_HET.CD_HET
FROM T_HET INNER JOIN (T_HFR INNER JOIN (T_HVE INNER JOIN T_HOT001 ON T_HVE.CD_HOT = T_HOT001.CD_HOT) ON (T_HFR.CD_HOT = T_HVE.CD_HOT) AND (T_HFR.CD_HVE = T_HVE.CD_HVE)) ON (T_HET.CD_HOT = T_HFR.CD_HOT) AND (T_HET.CD_HVE = T_HFR.CD_HVE) AND (T_HET.CD_HFR = T_HFR.CD_HFR)
 ' + @condicao2 + @CondPeriodo1 + @CondPeriodo2 + '
)  AS VRPesquisa2 
 ON (VRPesquisa.Voo = VRPesquisa2.Voo) AND (VRPesquisa.CD_HVE = VRPesquisa2.CD_HVE) AND (VRPesquisa.CD_HFR = VRPesquisa2.CD_HFR)
WHERE
/* Esta condicao deve refeltir a orientacao do voo:                */
/* Refencia->Destino    :VRPesquisa.CD_HET >= VRPesquisa2.CD_HET   */
/* Origem  ->Referencia :VRPesquisa.CD_HET <= VRPesquisa2.CD_HET   */
/* Sem pesquisa         :VRPesquisa.CD_HET  = VRPesquisa2.CD_HET   */

   (VRPesquisa.CD_HET ' + @condicao3 + ' VRPesquisa2.CD_HET)

) 
 AS VRFinal 
 INNER JOIN 
 (((T_HET INNER JOIN (T_HFR INNER JOIN (T_HVE INNER JOIN T_HOT001 ON T_HVE.CD_HOT = T_HOT001.CD_HOT) ON (T_HFR.CD_HOT = T_HVE.CD_HOT) AND (T_HFR.CD_HVE = T_HVE.CD_HVE)) ON (T_HET.CD_HOT = T_HFR.CD_HOT) AND (T_HET.CD_HVE = T_HFR.CD_HVE) AND (T_HET.CD_HFR = T_HFR.CD_HFR)) INNER JOIN (T_AER AS AER_Origem INNER JOIN T_CID AS CID_Origem ON AER_Origem.CD_CID = CID_Origem.CD_CID) ON T_HET.SG_AER_ORI = AER_Origem.SG_AER_ICA) INNER JOIN (T_AER AS AER_Destino INNER JOIN T_CID AS CID_Destino ON AER_Destino.CD_CID = CID_Destino.CD_CID) ON T_HET.SG_AER_DES = AER_Destino.SG_AER_ICA) ON (VRFinal.Voo = T_HET.CD_HOT) AND (VRFinal.CD_HVE = T_HET.CD_HVE) AND (VRFinal.CD_HFR = T_HET.CD_HFR)

ORDER BY VRFinal.Voo, VRFinal.CD_HVE, VRFinal.CD_HFR, T_HET.CD_HET ')

GO

/****** Object:  Stored Procedure dbo.sp_TotalChegadas    Script Date: 4/10/01 6:31:03 PM ******/
/****** Object:  Stored Procedure dbo.sp_TotalChegadas    Script Date: 3/15/01 3:54:23 PM ******/
/*
 Retorna o total de voos validos que estao chegando ao aeroporto 
*/

CREATE PROCEDURE sp_TotalChegadas AS
SELECT
	count(*) AS total 
FROM
	T_CHG CHG, T_COM COM, T_SIT SIT 
WHERE
	CHG.FL_CHG_TEL = 1 AND CHG.CD_SIT <> 10 AND
	CHG.CD_COM = COM.CD_COM AND 
	CHG.CD_SIT = SIT.CD_SIT

GO

/****** Object:  Stored Procedure dbo.sp_TotalChegadasCompleto    Script Date: 4/10/01 6:31:04 PM ******/
/****** Object:  Stored Procedure dbo.sp_TotalChegadasCompleto    Script Date: 22/03/2001 11:35:55 ******/
CREATE PROCEDURE sp_TotalChegadasCompleto AS
/*
 Retorna o total de voos validos que estao chegando ao aeroporto 
*/
SELECT
	count(*) AS total 
FROM
	T_CHG CHG, T_COM COM, T_SIT SIT 
WHERE
	CHG.FL_CHG_TEL = 1 AND
	CHG.CD_SIT = 10 AND
	DATEDIFF(dd,DT_CHG,getdate()) <= 1 AND
	CHG.CD_COM = COM.CD_COM AND 
	CHG.CD_SIT = SIT.CD_SIT
GO

/****** Object:  Stored Procedure dbo.sp_TotalPartidas    Script Date: 4/10/01 6:31:04 PM ******/
/****** Object:  Stored Procedure dbo.sp_TotalPartidas    Script Date: 3/15/01 3:54:23 PM ******/
/*
 Retorna o total de voos validos que estao partindo do aeroporto 
*/
CREATE PROCEDURE sp_TotalPartidas AS

SELECT
	count(*) AS total 
FROM
	T_PAR PAR, T_COM COM, T_SIT SIT
WHERE
	PAR.FL_PAR_TEL = 1 AND PAR.CD_SIT <> 10 AND 
	PAR.CD_COM = COM.CD_COM 
	AND PAR.CD_SIT = SIT.CD_SIT

GO

/****** Object:  Stored Procedure dbo.sp_TotalPartidasCompleto    Script Date: 4/10/01 6:31:04 PM ******/
/****** Object:  Stored Procedure dbo.sp_TotalPartidasCompleto    Script Date: 22/03/2001 11:35:55 ******/
CREATE PROCEDURE sp_TotalPartidasCompleto AS
/*
 Retorna o total de voos validos que estao partindo ou j� partiram do aeroporto 
*/
SELECT
	count(*) AS total 
FROM
	T_PAR PAR, T_COM COM, T_SIT SIT
WHERE
	PAR.FL_PAR_TEL = 1 AND 
	PAR.CD_SIT = 10 AND
	DATEDIFF(dd,PAR.DH_PAR_EST,getdate()) <= 1 AND
	PAR.CD_COM = COM.CD_COM 
	AND PAR.CD_SIT = SIT.CD_SIT
GO

